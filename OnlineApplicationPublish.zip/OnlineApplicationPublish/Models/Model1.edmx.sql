
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 12/26/2018 16:17:14
-- Generated from EDMX file: C:\AGILE\IESR\PL\IESR\Portals\OnlinePlatform\OnlinePlatform\Models\Model1.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [IESR 2018];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Applicants'
CREATE TABLE [dbo].[Applicants] (
    [UserID] int IDENTITY(1,1) NOT NULL,
    [Email] nvarchar(250)  NOT NULL,
    [Password] nvarchar(max)  NOT NULL,
    [IsEmailVerified] bit  NOT NULL,
    [ActivationCode] uniqueidentifier  NOT NULL,
    [ResetPasswordCode] nvarchar(50)  NULL,
    [ApplicationNo] nvarchar(50)  NULL,
    [IdNumber] nvarchar(50)  NULL,
    [IsEnrolled] bit  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [UserID] in table 'Applicants'
ALTER TABLE [dbo].[Applicants]
ADD CONSTRAINT [PK_Applicants]
    PRIMARY KEY CLUSTERED ([UserID] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------