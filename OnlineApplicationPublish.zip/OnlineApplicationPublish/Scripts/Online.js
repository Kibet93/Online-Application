﻿function RemoveRow(Action, RowID) {
    if (Action === "Update") {
        $.ajax({
            url: "deleteRow?",
            data: { Key: $("#Key_" + RowID).val() /* add other additional parameters */ },
            cache: false,
            type: "POST",
            dataType: "html",

            success: function (data, textStatus, XMLHttpRequest) {
                $("#info_Ln").show();
                $("#info_Ln").html(data);
            }
        });
        $("#ThisRow_" + RowID).remove();
    }
    else
        $("#NewRow_" + RowID).remove();
    document.getElementById("LastRowID").value = RowID - 1;
}
function AddRow(Action, Lineno) {
    var mytable = document.getElementById("LineTable");
    var row = mytable.insertRow(mytable.rows.length);
    //next row
    var previousrow = document.getElementById("LastRowID").value;
    var nextrow = Number(previousrow) + Number(1);
    document.getElementById("LastRowID").value = nextrow;
    row.id = "NewRow_" + nextrow;
    // Insert a cell in the row at index 0
    var Cell1 = row.insertCell(0);
    // Append Input Element to the cell
    var element1 = document.createElement("select");
    element1.setAttribute("class", "form-control");
    var options_str = "";
    if (Action ==="Create") {
        element1.id = "Course_Code_" + nextrow;
        element1.name = "Course_Code_" + nextrow;
        if (previousrow ==="0")
            options_str = $("#Course_Code").html();
        else
            options_str = $("#Course_Code_" + previousrow).html();
    }
    else if (Action === "Update") {
        element1.id = "UCourse_Code_" + nextrow;
        element1.name = "UCourse_Code_" + nextrow;
        if (Lineno !== "0")
            options_str = $("#UCourse_Code_" + Lineno).html();
        else
            options_str = $("#UCourse_Code_" + previousrow).html();
    }
    element1.innerHTML = options_str;
    Cell1.appendChild(element1);

    var Cell2 = row.insertCell(1);
    var element2 = document.createElement("select");
    element2.type = "Text";
    element2.setAttribute("class", "form-control");
    if (Action ==="Create") {
        element2.name = "Category_" + nextrow;
        element2.id = "Category_" + nextrow;
    }
    else if (Action ==="Update") {
        element2.name ="UCategory_" + nextrow;
        element2.id ="UCategory_" + nextrow;
    }
    //element2.onchange = function () { ValidateDebitDetails(Action, element2.value, nextrow) };
    Cell2.appendChild(element2);

    var Cell3 = row.insertCell(2);
    var element3 = document.createElement("input");
    element3.type = "text";
    element3.setAttribute("class", "form-control");
    if (Action ==="Create") {
        element3.id ="Mode_of_Study_" + nextrow;
        element3.name = "Mode_of_Study_" + nextrow;
    }
    else if (Action === "Update") {
        element3.id = "UMode_of_Study_" + nextrow;
        element3.name = "UMode_of_Study_" + nextrow;
    }
    //element3.onchange = function () { ValidatePolicyDetails(Action, element3.value, nextrow) };
    Cell3.appendChild(element3);


    var Cell4 = row.insertCell(3);
    Cell5.innerHTML += '<i class="fa fa-plus-circle" Onclick="AddRow(\'' + Action + '\',0);" ></i>';
    Cell5.innerHTML += '<i class="fa fa-minus-circle" Onclick="RemoveRow(\'' + Action + '\',\'' + nextrow + '\');" ></i>';
}


